import { s as st } from '../index-esm-30f684a2.js';

console.log("content script working");const o=setInterval((()=>{const n=document.querySelector(".app-container-inview > iframe");if(n){console.log("🇻🇳 ~ file: index.js ~ line 3 ~ iframeEle",n);let l;null!==(l=/token=(.*)&/gm.exec(n.src))&&(console.log("🇻🇳 ~ file: index.js ~ line 9 ~ match",l),console.log("🇻🇳 ~ file: index.js ~ line 9 ~ match[0]",l[1]),st.local.set({backdoorToken:l[1]})),st.local.get("backdoorToken").then((({backdoorToken:e})=>{console.log("🇻🇳 ~ file: index.js ~ line 17 ~ backdoorToken",e);})),clearInterval(o);}}),500);
